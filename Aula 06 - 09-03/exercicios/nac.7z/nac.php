<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>PHP</title>
</head>
<body>

    <?php

    echo "<h2> Questão 1:</h2>";
    echo "C) $";

    echo "<br>";

    echo "<h2> Questão 2:</h2>";
    echo "D) I, III, IV";

    echo "<br>";

    echo "<h2> Questão 3:</h2>";
    /*
	Antonio tem 1,50m e cresce 2 centímetros por ano, enquanto Bernardo tem 1,20m e cresce 3 centímetros por ano. Construa um programa em PHP que mostre em quantos anos serão necessários para que Bernardo seja maior que Antonio.*/

    $antonio = 1.5;
    $bernardo = 1.2;

    $i = 0;

        while ($bernardo < $antonio) {
                $bernardo = $bernardo + 0.03;
                $antonio = $antonio + 0.02;
                $i++;
            }

    echo "Serão necessários $i anos.";

    echo "<br>";

    echo "<h2> Questão 4:</h2>";

    /*
    Baseado no Array contendo 7 números, responda as questões abaixo:
    [String] = ["85","48","31","75","64","13","45"];
    (com respostas desenvolvidas com scripts de programação em PHP)
  */
     $lista = array(85,48,31,75,64,13,45);

echo "a) Maior número: ";
echo max($lista);
echo "<br>";
echo "b) Menor número: ";
echo min($lista);
echo "<br>";
echo "c) Impressão da lista: ";
print_r($lista);
echo "<br>";
echo "d) Ordem crescente: ";
sort($lista);
    print_r($lista);
echo "<br>";


    echo "<h2> Questão 5:</h2>";

?>

    <h2> Questão 6:</h2>





</body>
</html>
